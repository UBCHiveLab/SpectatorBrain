# Mixed Reality Toolkit SDK - Features

This folder contains the core mixed Reality Feature concrete implementations.  These are completely optional to use and can be replaced with your own system should you wish to.

> More details needed on creating your own system, or replacing one.