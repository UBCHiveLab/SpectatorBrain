# Mixed Reality Toolkit - SDK - Elements - Audio

This folder contains all the individual audio assets used to build MRTK solutions