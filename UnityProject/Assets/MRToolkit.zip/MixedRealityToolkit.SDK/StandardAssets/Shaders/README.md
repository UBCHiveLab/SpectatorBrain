# Mixed Reality Toolkit - SDK - Elements - Shaders

This folder contains all the individual shader assets used to build MRTK solutions